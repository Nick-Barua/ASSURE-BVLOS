"""Implementation tests; not proof of an operational aircraft safety case."""
from pathlib import Path
import itertools
import unittest
import numpy as np
from assure_bvlos.model import load_config,generate,aggregate,authority,hard_floor,critical_labels,evaluate,Supervisor

ROOT=Path(__file__).resolve().parents[1]
class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.c=load_config(ROOT/'config.json');cls.d=generate(cls.c,991,n=10000)
    def test_01_replay(self):
        b=generate(self.c,991,n=10000)
        for k,v in self.d.items():np.testing.assert_array_equal(v,b[k])
    def test_02_distinct_seeds(self):
        self.assertFalse(np.array_equal(self.d['risk'],generate(self.c,992,n=10000)['risk']))
    def test_03_generator_bounds(self):
        r=self.d['risk'];self.assertTrue(np.all((r>=0)&(r<=1)))
        for k in ['disagreement','age_score','uniform']:self.assertTrue(np.all((self.d[k]>=0)&(self.d[k]<=1)))
    def test_04_index_bounds(self):
        r=np.random.default_rng(4).random((10000,5));r[:2]=[np.zeros(5),np.ones(5)]
        out=aggregate(r,self.c['weights']);self.assertTrue(np.all((out>=0)&(out<=1)));self.assertEqual(out[0],0);self.assertEqual(out[1],1)
    def test_05_monotonicity(self):
        r=self.d['risk'];b=aggregate(r,self.c['weights'])
        for i in range(5):
            u=r.copy();u[:,i]=np.minimum(1,u[:,i]+.01);self.assertTrue(np.all(aggregate(u,self.c['weights'])>=b-1e-14))
    def test_06_arithmetic_order(self):
        r=self.d['risk'];w=self.c['weights']
        self.assertTrue(np.all(aggregate(r,w)>=aggregate(r,w,'arithmetic')-1e-14))
    def test_07_maximum_bound(self):self.assertTrue(np.all(aggregate(self.d['risk'],self.c['weights'])<=self.d['risk'].max(axis=1)+1e-14))
    def test_08_equal_inputs(self):
        v=np.linspace(0,1,1001);np.testing.assert_allclose(aggregate(np.repeat(v[:,None],5,axis=1),self.c['weights']),v,atol=1e-14)
    def test_09_zero_weight_endpoint(self):
        r=np.array([[1,.2,.2,.2,.2],[1,1,.2,.2,.2]])
        out=aggregate(r,[0,.25,.25,.25,.25]);self.assertAlmostEqual(out[0],.2);self.assertEqual(out[1],1)
    def test_10_derivative(self):
        r=np.array([[.2,.3,.4,.5,.6]]);w=np.array(self.c['weights']);h=1e-6;base=aggregate(r,w)[0]
        for i in range(5):
            p=r.copy();m=r.copy();p[0,i]+=h;m[0,i]-=h
            fd=(aggregate(p,w)[0]-aggregate(m,w)[0])/(2*h)
            self.assertAlmostEqual(fd,w[i]*(1-base)/(1-r[0,i]),places=7)
    def test_11_invalid_input(self):
        for r in [np.full((1,5),np.nan),np.full((1,5),-1.),np.full((1,5),1.1)]:
            with self.assertRaises(ValueError):aggregate(r,self.c['weights'])
    def test_12_invalid_weights(self):
        for w in [[0]*5,[-.2,.3,.3,.3,.3],[.2,.2,.2,.2,np.nan]]:
            with self.assertRaises(ValueError):aggregate(self.d['risk'],w)
    def test_13_clipped_score(self):
        _,s=authority(self.d,self.c,lambda_disagreement=10.,lambda_age=10.)
        self.assertTrue(np.all((s>=0)&(s<=1)));self.assertTrue(np.any(s==1))
    def test_14_hard_priority_32_combinations(self):
        for nav,flight,geo,low,high in itertools.product([False,True],repeat=5):
            d={k:v[:1].copy() for k,v in self.d.items()};d['navigation_invalid'][:]=nav;d['flight_control_failed'][:]=flight;d['geofence_breach'][:]=geo
            d['energy'][:]=.1 if low else .8;d['risk'][:]=.1;d['risk'][:,0]=.95 if high else .1
            expected=4 if flight or low else (3 if nav or geo or high else 0)
            self.assertEqual(int(hard_floor(d,self.c)[0]),expected)
            self.assertGreaterEqual(int(authority(d,self.c)[0][0]),expected)
    def test_15_C2_protected(self):
        a,_=authority(self.d,self.c);m=self.d['risk'][:,0]>=self.c['overrides']['C2_protected'];self.assertTrue(np.all(a[m]>=2))
    def test_16_probability_pair_order(self):
        e=evaluate(self.d,self.c);self.assertTrue(np.all(e['p_assure']<=e['p_baseline']+1e-15));self.assertTrue(np.all(e['y_assure']<=e['y_baseline']))
    def test_17_zero_mitigation(self):
        e=evaluate(self.d,self.c,mitigation_scale=0.)
        np.testing.assert_array_equal(e['p_assure'],e['p_baseline']);np.testing.assert_array_equal(e['y_assure'],e['y_baseline'])
    def test_18_more_conservative_thresholds(self):
        lo,_=authority(self.d,self.c,threshold_multiplier=.9);hi,_=authority(self.d,self.c,threshold_multiplier=1.1)
        self.assertTrue(np.all(lo>=hi))
    def test_19_ablation_hard_limits_preserved(self):
        b=hard_floor(self.d,self.c)
        for i in range(5):self.assertTrue(np.all(authority(self.d,self.c,omit=i)[0]>=b))
    def test_20_immediate_escalation(self):
        s=Supervisor();self.assertEqual(s.step(.1,3),3)
    def test_21_hysteretic_recovery(self):
        s=Supervisor();s.step(.65)
        for _ in range(9):self.assertEqual(s.step(.1),3)
        self.assertEqual(s.step(.1),2)
    def test_22_recovery_counter_reset(self):
        s=Supervisor();s.step(.5)
        for _ in range(8):s.step(.1)
        s.step(.4)
        for _ in range(9):self.assertEqual(s.step(.1),2)
        self.assertEqual(s.step(.1),1)
    def test_23_S4_latch(self):
        s=Supervisor();s.step(.8)
        for _ in range(50):self.assertEqual(s.step(.1),4)
    def test_24_missing_monitor_fail_safe(self):
        s=Supervisor();self.assertEqual(s.step(float('nan')),3)
    def test_25_recovery_guard(self):
        s=Supervisor();s.step(.65)
        for _ in range(20):self.assertEqual(s.step(.1,recovery_permitted=False),3)
    def test_26_threshold_boundary(self):
        for i,t in enumerate(self.c['thresholds']):self.assertEqual(Supervisor().step(t),i+1)
    def test_27_probability_bounds(self):
        for extra in [0,.5,1.]:
            e=evaluate(self.d,self.c,additional_risk=extra)
            for k in ['p_unmitigated','p_baseline','p_assure']:self.assertTrue(np.all((e[k]>=0)&(e[k]<=1)))
    def test_28_critical_label_union(self):
        comp,crit=critical_labels(self.d,self.c);self.assertTrue(np.all(crit>=comp));self.assertTrue(np.all(crit[hard_floor(self.d,self.c)>0]))
if __name__=='__main__':unittest.main(verbosity=2)
