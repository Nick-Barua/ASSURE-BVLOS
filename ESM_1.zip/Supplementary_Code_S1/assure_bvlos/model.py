"""Transparent independent-state model. NOT operational flight-control software.

All numbers come from config.json. Unknown original settings have been newly
specified and are not represented as recovered parameters. Probability here is
per synthetic sampled state, not per flight, mission, hour or kilometre.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import json
import numpy as np
from numpy.typing import NDArray
from scipy.special import expit

FloatArray = NDArray[np.float64]
Config = dict[str, Any]

def load_config(path: str | Path) -> Config:
    c=json.loads(Path(path).read_text())
    w=np.asarray(c['weights'],float); t=np.asarray(c['thresholds'],float)
    if w.shape != (5,) or np.any(w<0) or not np.isclose(w.sum(),1):
        raise ValueError('Five nonnegative weights must sum to one.')
    if t.shape != (4,) or not np.all(np.diff(t)>0) or t[0]<=0 or t[-1]>=1:
        raise ValueError('Four strictly increasing thresholds must lie in (0,1).')
    m=np.asarray(c['mitigation'],float)
    if m.shape!=(5,) or np.any(m<0) or np.any(m>1) or np.any(np.diff(m)<0):
        raise ValueError('Mitigation must be a nondecreasing five-element vector in [0,1].')
    return c

def generate(c:Config, seed:int, n:int|None=None) -> dict[str,NDArray]:
    """Generate all primary inputs with PCG64; conditionally independent given scenario/link."""
    n=c['n_states'] if n is None else n
    if not isinstance(n,int) or n<1: raise ValueError('n must be a positive integer')
    rng=np.random.Generator(np.random.PCG64(seed)); g=c['generator']; z=c['normalisation']
    scenario=rng.choice(3,n,p=c['scenario_probabilities']); link=rng.choice(3,n,p=c['link_probabilities'])
    def at(key,index): return np.asarray(g[key],float)[index]
    def clip(x,key): return np.clip(x,*g[key])
    rtt=clip(rng.lognormal(np.log(at('rtt_median_ms',link)),at('rtt_log_sigma',link)),'rtt_clip_ms')
    jitter=clip(rng.gamma(at('jitter_shape',link),at('jitter_scale_ms',link)),'jitter_clip_ms')
    loss=clip(rng.beta(at('loss_alpha',link),at('loss_beta',link)),'loss_clip')
    conf=clip(rng.normal(at('confidence_mean',scenario),at('confidence_sd',scenario)),'confidence_clip')
    disagreement=np.clip(rng.beta(g['disagreement_alpha'],g['disagreement_beta'],n)+at('disagreement_offset',scenario),0,1)
    provenance=np.clip(rng.beta(g['provenance_alpha'],g['provenance_beta'],n)+at('provenance_offset',scenario),0,1)
    age=clip(rng.lognormal(np.log(at('data_age_median_h',scenario)),at('data_age_log_sigma',scenario)),'data_age_clip_h')
    weather=rng.beta(at('weather_alpha',scenario),at('weather_beta',scenario))
    exposure=rng.beta(at('exposure_alpha',scenario),at('exposure_beta',scenario))
    energy=clip(rng.normal(at('energy_mean',scenario),at('energy_sd',scenario)),'energy_clip')
    health=rng.beta(g['health_alpha'],g['health_beta'],n)
    nav=rng.random(n)<at('navigation_invalid_probability',scenario)
    flight=rng.random(n)<at('flight_control_failed_probability',scenario)
    geofence=rng.random(n)<at('geofence_breach_probability',scenario)
    cc=z['C2_coefficients']; cs=z['C2_scales']
    c2=cc[0]*np.clip(rtt/cs[0],0,1)+cc[1]*np.clip(jitter/cs[1],0,1)+cc[2]*np.clip(loss/cs[2],0,1)
    ec=z['environment_coefficients']; vc=z['vehicle_coefficients']
    risk=np.column_stack([c2,1-conf,provenance,ec[0]*weather+ec[1]*exposure,vc[0]*(1-energy)+vc[1]*health])
    age_score=-np.expm1(-age/np.asarray(z['data_age_tau_h'])[scenario])
    out=dict(scenario=scenario.astype(np.int8),link=link.astype(np.int8),rtt_ms=rtt,jitter_ms=jitter,
             packet_loss=loss,sensor_confidence=conf,disagreement=disagreement,provenance_deficit=provenance,
             data_age_h=age,age_score=age_score,weather=weather,exposure=exposure,energy=energy,
             health_deficit=health,navigation_invalid=nav,flight_control_failed=flight,geofence_breach=geofence,
             risk=risk,uniform=rng.random(n))
    return out

def aggregate(risk:FloatArray,weights:FloatArray|list[float],kind:str='multiplicative')->FloatArray:
    x=np.asarray(risk,float); w=np.asarray(weights,float)
    if x.ndim!=2 or w.shape!=(x.shape[1],) or not np.all(np.isfinite(x)) or np.any(x<0) or np.any(x>1):
        raise ValueError('Risk must be a finite matrix in [0,1] with a compatible weight vector.')
    if not np.all(np.isfinite(w)) or np.any(w<0) or not np.isclose(w.sum(),1):
        raise ValueError('Weights must be finite, nonnegative and sum to one.')
    mask=w>0
    if kind=='multiplicative':
        # Exact endpoints: omit zero-weight domains instead of evaluating 0**0.
        with np.errstate(divide='ignore'):
            log_product=np.sum(np.log1p(-x[:,mask])*w[mask],axis=1)
        return np.clip(-np.expm1(log_product),0,1)
    if kind=='arithmetic': return x@w
    if kind=='maximum': return x[:,mask].max(axis=1)
    raise ValueError('Unknown aggregation kind: '+kind)

def hard_floor(data:dict[str,NDArray],c:Config)->NDArray[np.int8]:
    o=c['overrides']; r=data['risk']; n=len(r)
    out=np.zeros(n,dtype=np.int8)
    hard3=data['navigation_invalid']|data['geofence_breach']|(r[:,0]>=o['C2_hard'])
    hard4=data['flight_control_failed']|(data['energy']<=o['critical_energy'])
    out[hard3]=3;out[hard4]=4
    return out

def critical_labels(data:dict[str,NDArray],c:Config)->tuple[NDArray[np.bool_],NDArray[np.bool_]]:
    r=data['risk'];k=c['critical']
    compound=((r[:,0]>=k['C2'])&(r[:,1]>=k['Sensing_C2']))|((r[:,3]>=k['Environment'])&(r[:,4]>=k['Vehicle']))|((r[:,2]>=k['Data'])&(r[:,1]>=k['Sensing_Data']))
    return compound,compound|(hard_floor(data,c)>0)

def authority(data:dict[str,NDArray],c:Config,*,weights=None,threshold_multiplier:float=1.,kind:str='multiplicative',lambda_disagreement=None,lambda_age=None,omit:int|None=None):
    """Memoryless authority assignments for the independent-state experiment.

    Ablation removes a domain and its associated uncertainty penalty, but not
    safety-critical hard overrides or the complete-input evaluation labels.
    """
    w=np.array(c['weights'] if weights is None else weights,dtype=float)
    ls=c['lambda_disagreement'] if lambda_disagreement is None else float(lambda_disagreement)
    la=c['lambda_age'] if lambda_age is None else float(lambda_age)
    if ls<0 or la<0:raise ValueError('Uncertainty coefficients must be nonnegative.')
    if omit is not None:
        if omit not in range(5):raise ValueError('omit must be 0..4')
        w[omit]=0;w/=w.sum()
        if omit==1:ls=0.
        if omit==2:la=0.
    risk_index=aggregate(data['risk'],w,kind)
    score=np.clip(risk_index+ls*data['disagreement']+la*data['age_score'],0,1)
    thresholds=np.asarray(c['thresholds'])*threshold_multiplier
    if np.any(thresholds<=0) or np.any(thresholds>=1) or np.any(np.diff(thresholds)<=0):
        raise ValueError('Perturbed thresholds must remain strictly ordered in (0,1).')
    state=np.searchsorted(thresholds,score,side='right').astype(np.int8)
    protected=data['risk'][:,0]>=c['overrides']['C2_protected']
    state[protected]=np.maximum(state[protected],2)
    state=np.maximum(state,hard_floor(data,c))
    return state,score

def unmitigated_probability(data:dict[str,NDArray],c:Config,*,coefficient_multiplier:float=1.,intercept=None,interactions:bool=True)->FloatArray:
    r=data['risk'];s=c['surrogate'];a=np.asarray(s['linear_coefficients'])*coefficient_multiplier
    z=r@a+(s['intercept'] if intercept is None else intercept)
    if interactions:z=z+s['C2_sensing_interaction']*r[:,0]*r[:,1]+s['environment_vehicle_interaction']*r[:,3]*r[:,4]
    return expit(z)

def evaluate(data:dict[str,NDArray],c:Config,*,state=None,mitigation_scale:float=1.,additional_risk:float=0.,**surrogate_args):
    if mitigation_scale<0 or additional_risk<0:raise ValueError('Risk and mitigation scale cannot be negative')
    if state is None:state,_=authority(data,c)
    baseline=hard_floor(data,c)
    p=unmitigated_probability(data,c,**surrogate_args)
    m=np.minimum(np.asarray(c['mitigation'])*mitigation_scale,c['sensitivity']['mitigation_cap'])
    pb=p*(1-m[baseline]);pa=np.clip(p*(1-m[state])+additional_risk*(state>baseline),0,1)
    yb=(data['uniform']<pb);ya=(data['uniform']<pa)
    return dict(baseline_state=baseline,assure_state=state,p_unmitigated=p,p_baseline=pb,p_assure=pa,y_baseline=yb,y_assure=ya)

@dataclass
class Supervisor:
    """Logic-only hysteresis; caller supplies a score and independently computed floor.

    Immediate escalation; recovery by one band only after consecutive qualifying
    ticks. S4 is latched until a new Supervisor is explicitly instantiated/reset.
    A non-finite or out-of-range scalar score requests at least S3 and prevents
    recovery. Missing observations must be encoded as NaN, not Python None.
    """
    thresholds:tuple[float,...]=(.25,.42,.60,.76)
    margin:float=.04
    recovery_ticks:int=10
    state:int=0
    recovery_count:int=0

    def step(self,score:float,floor:int=0,recovery_permitted:bool=True)->int:
        if floor not in range(5):raise ValueError('floor must be 0..4')
        valid=np.isfinite(score) and 0<=score<=1
        if not valid:
            floor=max(floor,3);recovery_permitted=False;score=0.
        target=max(int(np.searchsorted(self.thresholds,score,side='right')),floor)
        if self.state==4:return 4
        if target>self.state:
            self.state=target;self.recovery_count=0
        elif self.state>0 and target<self.state and recovery_permitted and score<self.thresholds[self.state-1]-self.margin:
            self.recovery_count+=1
            if self.recovery_count>=self.recovery_ticks:
                self.state=max(self.state-1,target);self.recovery_count=0
        else:self.recovery_count=0
        return self.state
