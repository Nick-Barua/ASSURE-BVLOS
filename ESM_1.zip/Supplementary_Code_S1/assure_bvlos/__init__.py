"""ASSURE-BVLOS revision reference implementation; synthetic research only."""
__version__ = '2.0.0-revision'
