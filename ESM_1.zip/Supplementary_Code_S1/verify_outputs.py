#!/usr/bin/env python3
"""Verify the complete primary population against the supplied implementation.

This checks implementation/data consistency, not operational validity.
"""
from pathlib import Path
import argparse,hashlib,json
import numpy as np
import pandas as pd
from assure_bvlos.model import load_config,generate,authority,evaluate,critical_labels

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--results',default='results');parser.add_argument('--config',default='config.json');args=parser.parse_args()
 r=Path(args.results);cp=Path(args.config);c=load_config(cp);s=json.loads((r/'summary.json').read_text())
 checks={};checks['configuration_hash']=hashlib.sha256(cp.read_bytes()).hexdigest()==s['config_sha256']
 with np.load(r/'primary_states.npz',allow_pickle=False) as saved:
  d=generate(c,c['primary_seed']);state,score=authority(d,c);e=evaluate(d,c,state=state);comp,crit=critical_labels(d,c)
  actual={**d,**e,'score':score,'compound_critical':comp,'critical':crit}
  expected_hashes=json.loads((r/'primary_array_sha256.json').read_text())
  for name,value in actual.items():
   checks['array_'+name]=bool(np.array_equal(saved[name],value))
   checks['hash_'+name]=hashlib.sha256(np.ascontiguousarray(saved[name]).tobytes()).hexdigest()==expected_hashes[name]
  checks['headline_counts']=int(saved['y_baseline'].sum())==s['baseline_count'] and int(saved['y_assure'].sum())==s['assure_count']
  sc=pd.read_csv(r/'scenario_results.csv');checks['scenario_totals']=int(sc['n'].sum())==s['n'] and int(sc['baseline_count'].sum())==s['baseline_count'] and int(sc['assure_count'].sum())==s['assure_count']
  residual=pd.read_csv(r/'residual_by_authority.csv');checks['residual_totals']=int(residual.n.sum())==s['n'] and int(residual.residual_count.sum())==s['assure_count']
  checks['state_totals']=np.array_equal(np.bincount(saved['assure_state'],minlength=5),np.array(s['state_counts']))
  checks['nominal_nesting']=bool(np.all(saved['y_assure']<=saved['y_baseline']))
  counts=[int(np.sum(~saved['y_baseline']&~saved['y_assure'])),int(np.sum(~saved['y_baseline']&saved['y_assure'])),int(np.sum(saved['y_baseline']&~saved['y_assure'])),int(np.sum(saved['y_baseline']&saved['y_assure']))]
  checks['paired_cells']=counts==s['bootstrap']['joint_counts']
 report=dict(passed=all(checks.values()),checks=checks,interpretation='Consistency and same-environment replay only; not independent empirical validation.')
 (r/'verification_report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(f'{sum(checks.values())}/{len(checks)} output checks passed')
 if not report['passed']:raise SystemExit('Verification failed; inspect verification_report.json')
if __name__=='__main__':main()
