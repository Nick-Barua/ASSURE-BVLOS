#!/usr/bin/env python3
"""Run the complete revision study. No internet, equipment, model download or GPU needed.

Usage: python run_study.py --config config.json --output results
Plots are produced separately by `python make_figures.py`.
"""
from __future__ import annotations
import argparse, hashlib, json, platform, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
import scipy
from assure_bvlos.model import (load_config,generate,aggregate,authority,hard_floor,
    critical_labels,evaluate,Supervisor)

def py(v):
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    raise TypeError(type(v).__name__)

def save_json(path,value):path.write_text(json.dumps(value,indent=2,default=py,allow_nan=False)+'\n')

def metrics(data,c,state=None,**kw):
    if state is None:state,_=authority(data,c)
    e=evaluate(data,c,state=state,**kw);compound,crit=critical_labels(data,c);inter=state>=2
    tp=np.sum(inter&crit); n=len(state)
    return dict(n=n,baseline_count=int(e['y_baseline'].sum()),assure_count=int(e['y_assure'].sum()),
        baseline_probability=float(e['y_baseline'].mean()),assure_probability=float(e['y_assure'].mean()),
        difference=float(e['y_baseline'].mean()-e['y_assure'].mean()),
        relative_difference=float(1-e['y_assure'].mean()/e['y_baseline'].mean()),
        expected_baseline_probability=float(e['p_baseline'].mean()),expected_assure_probability=float(e['p_assure'].mean()),
        expected_difference=float(np.mean(e['p_baseline']-e['p_assure'])),
        intervention_fraction=float(inter.mean()),constraint_or_intervention_fraction=float((state>=1).mean()),
        critical_count=int(crit.sum()),compound_count=int(compound.sum()),
        critical_recall=float(tp/crit.sum()) if crit.any() else 0.,
        compound_recall=float(np.sum(inter&compound)/compound.sum()) if compound.any() else 0.,
        noncritical_intervention_fraction=float(np.sum(inter&~crit)/np.sum(~crit)),
        intervention_precision=float(tp/inter.sum()) if inter.any() else 0.,
        high_C2_count=int((data['risk'][:,0]>=c['overrides']['C2_protected']).sum()),
        high_C2_unprotected=int(np.sum((data['risk'][:,0]>=c['overrides']['C2_protected'])&(state<2))),
        state_counts=np.bincount(state,minlength=5).tolist())

def paired_bootstrap(yb,ya,b,seed,confidence):
    n=len(yb);counts=np.bincount(2*yb.astype(np.int8)+ya.astype(np.int8),minlength=4)
    rng=np.random.Generator(np.random.PCG64(seed))
    sample=rng.multinomial(n,counts/n,size=b)
    differences=(sample[:,2]-sample[:,1])/n
    baseline=(sample[:,2]+sample[:,3])/n
    relative=np.divide(differences,baseline,out=np.zeros_like(differences),where=baseline!=0)
    a=(1-confidence)/2
    return dict(joint_cell_order=['neither','ASSURE_only','baseline_only','both'],joint_counts=counts,
       replicates=b,seed=seed,confidence=confidence,
       difference_interval=np.quantile(differences,[a,1-a]),
       relative_difference_interval=np.quantile(relative,[a,1-a]),
       definition='Resample paired binary observations. Multinomial joint-cell resampling is exactly equivalent for statistics depending only on the four paired cell counts. Percentile interval; conditional Monte Carlo uncertainty only.')

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--config',default='config.json');ap.add_argument('--output',default='results')
    args=ap.parse_args();cfg_path=Path(args.config);out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    started=time.perf_counter();c=load_config(cfg_path)
    config_hash=hashlib.sha256(cfg_path.read_bytes()).hexdigest()
    print('Configuration SHA256:',config_hash,flush=True)
    d=generate(c,c['primary_seed']);a,score=authority(d,c);e=evaluate(d,c,state=a);s=metrics(d,c,state=a)
    comp,crit=critical_labels(d,c)
    s['config_sha256']=config_hash;s['primary_seed']=c['primary_seed']
    bc=c['bootstrap'];s['bootstrap']=paired_bootstrap(e['y_baseline'],e['y_assure'],bc['replicates'],bc['seed'],bc['confidence'])
    s['baseline_high_C2_unprotected']=int(np.sum((d['risk'][:,0]>=c['overrides']['C2_protected'])&(e['baseline_state']<2)))
    s['hard_override_count']=int((hard_floor(d,c)>0).sum())
    s['raw_probability_range']=[float(e['p_unmitigated'].min()),float(e['p_unmitigated'].max())]
    arrays=dict(d,**e,score=score,compound_critical=comp,critical=crit)
    np.savez_compressed(out/'primary_states.npz',**arrays)
    def flatten(arrays):
        flat={k:v for k,v in arrays.items() if v.ndim==1}
        for i,name in enumerate(c['domain_names']):flat['risk_'+name]=arrays['risk'][:,i]
        return pd.DataFrame(flat)
    flatten(arrays).head(1000).to_csv(out/'primary_states_sample_1000.csv',index=False,float_format='%.12g')
    by_scenario=[]
    for i,name in enumerate(c['scenario_names']):
        mask=d['scenario']==i;dd={k:v[mask] for k,v in d.items()}
        row=dict(scenario=name,**metrics(dd,c,state=a[mask]));row.pop('state_counts')
        for j,dom in enumerate(c['domain_names']):row['mean_'+dom]=float(dd['risk'][:,j].mean())
        row['mean_disagreement']=float(dd['disagreement'].mean());row['mean_age_score']=float(dd['age_score'].mean())
        by_scenario.append(row)
    pd.DataFrame(by_scenario).to_csv(out/'scenario_results.csv',index=False)
    residual=[]
    for i in range(5):
        m=a==i;yc=int(e['y_assure'][m].sum())
        residual.append(dict(state='S'+str(i),n=int(m.sum()),share=float(m.mean()),
            residual_count=yc,residual_share=yc/int(e['y_assure'].sum()),
            conditional_sample_probability=float(e['y_assure'][m].mean()) if m.any() else 0.,
            conditional_expected_probability=float(e['p_assure'][m].mean()) if m.any() else 0.,
            expected_probability_contribution=float(e['p_assure'][m].sum()/len(a)),
            compound_count=int(comp[m].sum()),critical_count=int(crit[m].sum())))
    pd.DataFrame(residual).to_csv(out/'residual_by_authority.csv',index=False)
    # All sweeps use the identical primary state population; settings were declared in config.json.
    threshold=[]
    for mult in c['sensitivity']['threshold_multipliers']:
        st,_=authority(d,c,threshold_multiplier=mult)
        row=dict(multiplier=mult,**metrics(d,c,state=st));row.pop('state_counts');threshold.append(row)
    pd.DataFrame(threshold).to_csv(out/'threshold_sweep.csv',index=False)
    ablation=[]
    for i,name in enumerate(c['domain_names']):
        st,_=authority(d,c,omit=i)
        row=dict(omitted_domain=name,associated_uncertainty_penalty_removed=(i in (1,2)),**metrics(d,c,state=st));row.pop('state_counts');ablation.append(row)
    pd.DataFrame(ablation).to_csv(out/'domain_ablation.csv',index=False)
    vehicle=[]
    for v in c['sensitivity']['vehicle_weights']:
        w=np.full(5,(1-v)/4);w[4]=v;st,_=authority(d,c,weights=w)
        row=dict(vehicle_weight=v,other_domain_weight=(1-v)/4,**metrics(d,c,state=st));row.pop('state_counts');vehicle.append(row)
    pd.DataFrame(vehicle).to_csv(out/'vehicle_weight_sweep.csv',index=False)
    weight=[];wc=c['sensitivity'];rng=np.random.Generator(np.random.PCG64(wc['dirichlet_seed']))
    for i,w in enumerate(rng.dirichlet(wc['dirichlet_alpha'],size=wc['dirichlet_draws'])):
        st,_=authority(d,c,weights=w);row=dict(draw=i,**metrics(d,c,state=st));row.pop('state_counts')
        for j,dom in enumerate(c['domain_names']):row['weight_'+dom]=w[j]
        weight.append(row)
    wf=pd.DataFrame(weight);wf.to_csv(out/'random_weight_sensitivity.csv',index=False)
    s['weight_sensitivity_ranges']={col:[float(wf[col].min()),float(wf[col].max())] for col in ['expected_difference','critical_recall','intervention_fraction']}
    uncertainty=[]
    for ls in c['sensitivity']['uncertainty_values']:
        for la in c['sensitivity']['uncertainty_values']:
            st,_=authority(d,c,lambda_disagreement=ls,lambda_age=la);row=dict(lambda_disagreement=ls,lambda_age=la,**metrics(d,c,state=st));row.pop('state_counts');uncertainty.append(row)
    pd.DataFrame(uncertainty).to_csv(out/'uncertainty_penalty_sweep.csv',index=False)
    comparators=[];matched=[];mandatory=(hard_floor(d,c)>0)|(d['risk'][:,0]>=c['overrides']['C2_protected'])
    target=int((a>=2).sum());need=target-int(mandatory.sum())
    for kind in ['multiplicative','arithmetic','maximum']:
        st,sc=authority(d,c,kind=kind);row=dict(aggregation=kind,**metrics(d,c,state=st));row.pop('state_counts');comparators.append(row)
        selected=mandatory.copy();ids=np.flatnonzero(~mandatory);rank=np.argsort(-sc[ids],kind='stable')
        selected[ids[rank[:need]]]=True
        matched.append(dict(aggregation=kind,intervention_count=int(selected.sum()),intervention_fraction=float(selected.mean()),
            mandatory_count=int(mandatory.sum()),critical_recall=float(np.sum(selected&crit)/crit.sum()),
            compound_recall=float(np.sum(selected&comp)/comp.sum()),
            note='Retrospective equal-budget ranking diagnostic on the same synthetic population; not a prospectively tuned or operational policy.'))
    pd.DataFrame(comparators).to_csv(out/'aggregation_comparison.csv',index=False)
    pd.DataFrame(matched).to_csv(out/'matched_budget_comparison.csv',index=False)
    surrogate=[]
    for mult in c['sensitivity']['coefficient_multipliers']:
        for intercept in c['sensitivity']['intercepts']:
            row=dict(coefficient_multiplier=mult,intercept=intercept,interactions=True,**metrics(d,c,state=a,coefficient_multiplier=mult,intercept=intercept));row.pop('state_counts');surrogate.append(row)
    row=dict(coefficient_multiplier=1.,intercept=c['surrogate']['intercept'],interactions=False,**metrics(d,c,state=a,interactions=False));row.pop('state_counts');surrogate.append(row)
    pd.DataFrame(surrogate).to_csv(out/'surrogate_sensitivity.csv',index=False)
    mitigation=[]
    for m in c['sensitivity']['mitigation_scales']:
        row=dict(mitigation_scale=m,**metrics(d,c,state=a,mitigation_scale=m));row.pop('state_counts');mitigation.append(row)
    pd.DataFrame(mitigation).to_csv(out/'mitigation_sensitivity.csv',index=False)
    costs=[]
    for k in c['sensitivity']['additional_intervention_risk']:
        row=dict(additional_intervention_risk=k,**metrics(d,c,state=a,additional_risk=k));row.pop('state_counts');costs.append(row)
    pd.DataFrame(costs).to_csv(out/'intervention_risk_sensitivity.csv',index=False)
    # Solve the model's break-even added conditional probability; no empirical interpretation.
    lo,hi=0.,1.
    for _ in range(60):
        mid=(lo+hi)/2;ee=evaluate(d,c,state=a,additional_risk=mid)
        if np.mean(ee['p_baseline']-ee['p_assure'])>0:lo=mid
        else:hi=mid
    s['additional_intervention_risk_break_even']=(lo+hi)/2
    s['additional_intervention_fraction']=float((a>e['baseline_state']).mean())
    repeated=[]
    for seed in c['seeds']:
        dd=d if seed==c['primary_seed'] else generate(c,seed)
        row=dict(seed=seed,**metrics(dd,c));row.pop('state_counts');repeated.append(row)
    rf=pd.DataFrame(repeated);rf.to_csv(out/'seed_results.csv',index=False)
    s['between_seed']={col:dict(mean=float(rf[col].mean()),sd=float(rf[col].std(ddof=1)),minimum=float(rf[col].min()),maximum=float(rf[col].max())) for col in ['baseline_probability','assure_probability','difference','expected_difference','critical_recall','intervention_fraction']}
    # Separate prescribed-score temporal logic test. It is not a flight or mission simulation.
    tc=c['temporal'];trng=np.random.Generator(np.random.PCG64(tc['seed']));temporal=[];trace0=None
    base=np.repeat(tc['block_scores'],tc['block_length'])
    for j in range(tc['traces']):
        sc=np.clip(base+trng.normal(0,tc['noise_sd'],tc['ticks']),0,1)
        floor=np.zeros(tc['ticks'],dtype=np.int8)
        floor[slice(*tc['C2_override_ticks'])]=2;floor[slice(*tc['hard_override_ticks'])]=3
        plain=np.maximum(np.searchsorted(c['thresholds'],sc,side='right'),floor)
        sup=Supervisor(tuple(c['thresholds']),tc['release_margin'],tc['recovery_ticks'])
        hyst=np.array([sup.step(float(v),int(f)) for v,f in zip(sc,floor)],dtype=np.int8)
        temporal.append(dict(trace=j,static_switches=int(np.count_nonzero(np.diff(plain))),
            hysteretic_switches=int(np.count_nonzero(np.diff(hyst))),
            static_protected_fraction=float((plain>=2).mean()),hysteretic_protected_fraction=float((hyst>=2).mean()),
            score_band_underresponses=int(np.sum(hyst<plain)),override_violations=int(np.sum(hyst<floor))))
        if j==0:trace0=pd.DataFrame(dict(tick=np.arange(tc['ticks']),score=sc,floor=floor,memoryless_state=plain,hysteretic_state=hyst))
    tf=pd.DataFrame(temporal);tf.to_csv(out/'temporal_logic_results.csv',index=False);trace0.to_csv(out/'temporal_example.csv',index=False)
    s['temporal_logic']={col:dict(mean=float(tf[col].mean()),minimum=int(tf[col].min()) if 'fraction' not in col else float(tf[col].min()),maximum=int(tf[col].max()) if 'fraction' not in col else float(tf[col].max()),total=int(tf[col].sum()) if 'fraction' not in col else None) for col in tf.columns if col!='trace'}
    # Byte-level array equality from an independent replay of the primary generation and evaluation.
    d2=generate(c,c['primary_seed']);a2,sc2=authority(d2,c);e2=evaluate(d2,c,state=a2)
    checks={k:bool(np.array_equal(v,d2[k])) for k,v in d.items()}
    checks.update({'output_'+k:bool(np.array_equal(v,e2[k])) for k,v in e.items()})
    checks['score']=bool(np.array_equal(score,sc2))
    if not all(checks.values()):raise RuntimeError('Reproduction failure')
    s['primary_replay_exact']=all(checks.values())
    save_json(out/'replay_checks.json',checks)
    array_hashes={k:hashlib.sha256(np.ascontiguousarray(v).tobytes()).hexdigest() for k,v in arrays.items()}
    save_json(out/'primary_array_sha256.json',array_hashes)
    s['elapsed_seconds']=time.perf_counter()-started
    s['environment']={'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'pandas':pd.__version__,'platform':platform.platform()}
    save_json(out/'summary.json',s)
    print(json.dumps({k:s[k] for k in ['baseline_count','assure_count','difference','expected_difference','critical_recall','intervention_fraction','primary_replay_exact','elapsed_seconds']},indent=2),flush=True)
    print('All results written to',out.resolve(),flush=True)

if __name__=='__main__':main()
