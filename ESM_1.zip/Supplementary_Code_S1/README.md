# ASSURE-BVLOS — new reference evaluation, 2.0.0-revision

**Aerospace Systems** manuscript: *ASSURE-BVLOS: Runtime Assurance for Risk-Adaptive Space–Air–Ground Unmanned Aircraft Operations*.

Author/correspondent: Nick Barua, s.nick.barua@gmail.com.

Affiliations: AN Holdings Co., Nishinomiya, Hyogo, Japan; Shiga University of Medical Science, Otsu, Shiga, Japan.

**Online Resource 1 (ESM_1.zip): Supplementary Code S1.** The accompanying methods document is Online Resource 2 (ESM_2.pdf).

## Provenance — read first

This is a newly implemented evaluation of the documented ASSURE-BVLOS framework. The executable implementation and state-level outputs behind the earlier manuscript were unavailable. Missing values have been newly specified, and the current manuscript replaces the earlier numerical results. This is **not recovery or verified reproduction of the original simulation**. No parameter was chosen to match the old headline result. `config.json` distinguishes retained assumptions from newly specified ones; its hash identifies the configuration used for the supplied run. The recorded configuration is not evidence of external preregistration.

No flight, UAS equipment, hardware-in-the-loop, human-in-the-loop, operational incident data or empirical intervention-effect estimate is included. The code is research software, **not an aircraft controller or certified safety mechanism**. All numerical probabilities refer to independent synthetic sampled states, not flights, hours, missions or kilometres.

## Run and check

The run used Python 3.13.5. Dependency versions are in `requirements.txt`. Install them in a separate environment, then execute from this folder:

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python run_study.py --config config.json --output replay
python verify_outputs.py --results replay
python make_figures.py --results replay --output replay_figures
```

No network access, API, model download, GPU or external dataset is needed after installing dependencies. `replay` preserves the supplied `results` folder. The same-environment primary arrays were regenerated exactly; a clean installation on another platform was not independently tested. For strict array equality, retain the tested dependency versions. Integer random seeds are identifiers, not dates of separate physical experiments.

## Actual primary results

- N = 100,000; PCG64 seed 20260918.
- Baseline: 10,739 / 100,000 = 10.739%.
- ASSURE-BVLOS: 8,083 / 100,000 = 8.083%.
- Paired difference: 2.656 percentage points; 95% paired empirical bootstrap interval 2.557–2.757 percentage points, 10,000 replicates.
- Nominal critical recall: 40.1964%; S2–S4 burden: 9.768%; S1–S4 combined: 75.554%.
- Twenty-eight implementation tests passed. These are finite implementation checks, not operational certification evidence.

The assumed ordered mitigation schedule structurally favours the adaptive policy. The headline reduction is **not independent safety-effectiveness evidence**. The adverse-intervention variant reverses the mean conditional comparison at an added probability of 0.05 per additional authority assignment. Arithmetic fusion slightly exceeds multiplicative recall at matched intervention burden. Those results are retained, not tuned away.

## File map

- `assure_bvlos/model.py`: generator, scalar fusion, overrides, outcome surrogate and separate hysteretic supervisor.
- `config.json`: all source distributions, mappings, fixed parameters, seeds and sweep grids.
- `run_study.py`: primary run, paired bootstrap, sensitivities, repeated seeds and separate prescribed-score logic tests.
- `tests/test_model.py`: 28 unit tests, including 32 hard-condition combinations within one test.
- `verify_outputs.py`: same-environment array replay, hashes and internal consistency checks.
- `results/primary_states.npz`: all 100,000 primary states and policy outcomes, not only a sample.
- `results/primary_states_sample_1000.csv`: convenience excerpt only.
- `data_dictionary.csv`: the meaning, shape and units of every NPZ array.
- `results/*.csv`: complete analysis outputs; `summary.json` stores headline summaries and environment versions.
- `results/primary_array_sha256.json`, `replay_checks.json`, `verification_report.json`: executed checks.
- `results/unit_tests.txt`: actual test output.
- `make_figures.py`: seven numerical figures from saved results, with PNG, vector-PDF and EPS outputs.
- `draw_conceptual_figures.py`: source-faithful vector redraws of the proposed architecture, authority bands and safety-case hierarchy. These are conceptual specifications, not numerical simulation outputs. Diagram 1 explicitly bypasses scalar fusion with the hard-limit path; Diagram 2 distinguishes recoverable states from latched S4; Diagram 3 uses G1–G5 claim identifiers. Pre-rendered PDF/EPS and 1200-dpi PNG files are supplied. Regeneration additionally needs ReportLab and an installed sans-serif font; Poppler is used for EPS conversion. These artwork dependencies are optional for numerical reproduction. No font files are distributed.
- `equations.tex`: LaTeX sources for the seven editable Word equations.
- `reference_list.json`: the references in the revised manuscript.
- `LICENSE`: BSD 3-Clause licence retained from the author-supplied repository.

## Interpretation and model boundary

The primary Monte Carlo states are independent. The baseline shares the hard-limit floors with the adaptive policy and assumes ordinary lower-level stabilisation. Fault flags test request priority; they do not model crash or recovery physics and are not independently added as consequences to the logistic surrogate. Confidence and provenance form nominal sensing/data scores; disagreement and age appear separately, avoiding double counting in this reference mapping.

Sensitivity calculations use the same primary population, except the explicitly repeated seeds and separate temporal test. Ablation removes a score and its associated uncertainty penalty where relevant but retains complete-input labels and safety-critical override channels. The matched-budget ranking is retrospective, not a held-out policy evaluation. Local Dirichlet perturbations are not Sobol sensitivity analysis.

The 500 temporal traces contain prescribed noisy scalar scores, not physical missions. Hysteresis reduces mean switching from 97.556 to 5.836 but increases protected-state occupancy from 29.699% to 63.727%. No closed-loop safety, execution timing or human workload is established.

## Archive status

This package is supplied for the revision. It has not been represented as already uploaded to GitHub or deposited on Zenodo, and it has **no new assigned DOI**. The earlier Version 1.0.0 documentation/figure snapshot must not be cited as containing these executable results. The author should preserve that provenance distinction when publishing a new version.

## Final submission check — 18 September 2026

The final packaging pass changed manuscript explanations, reference metadata and artwork; it did not alter the numerical model or `config.json`. A full same-environment rerun matched all 29 saved primary arrays exactly and all 16 result CSV files byte for byte. The 28 implementation tests and 65 output-consistency checks passed again. The audit logs document finite software checks, not independent external scientific validation. The manifest SHA-256 remains `82ab6791a44b771a66360d719d94c7ca6a800cd127e0f7e7721d3148fa256baa`.
