#!/usr/bin/env python3
"""Vector redraw of the manuscript's conceptual diagrams, not simulation outputs.

The architecture, five supervisory states and G1--G5 claim hierarchy come from
the supplied revision. Artwork clarifies routing and distinguishes proposed
claims from verified properties. ReportLab is needed only for these diagrams;
NumPy/SciPy are not used. Use --font for an installed TrueType sans-serif font.
No font files are distributed. pdftops/Poppler is needed only for EPS export.
"""
from pathlib import Path
import argparse, math, subprocess
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',default='figures')
    p.add_argument('--font',default=None)
    p.add_argument('--eps',action='store_true')
    args=p.parse_args()
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    font=args.font
    if font is None:
        candidates=[Path('/usr/share/fonts/truetype/croscore/Arimo-Regular.ttf'),
                    Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'),
                    Path('C:/Windows/Fonts/arial.ttf')]
        font=next((str(f) for f in candidates if f.exists()),None)
    if font is None:
        raise SystemExit('Supply --font with an installed sans-serif TrueType font.')
    pdfmetrics.registerFont(TTFont('DiagramSans',font))
    C=None
    def text(x,y,lines,size=9,lead=11):
        lines=lines.split('\n');C.setFont('DiagramSans',size)
        base=y+(len(lines)-1)*lead/2-size*.32
        for i,line in enumerate(lines):
            C.drawCentredString(x,base-i*lead,line)
    def rect(x,y,w,h,lines,size=9):
        C.setLineWidth(.75);C.roundRect(x,y,w,h,3,stroke=1,fill=0)
        text(x+w/2,y+h/2,lines,size)
    def line(points,arrow=False,dashed=False):
        C.setLineWidth(.7);C.setDash([3,2] if dashed else [])
        path=C.beginPath();path.moveTo(*points[0])
        for xy in points[1:]:path.lineTo(*xy)
        C.drawPath(path);C.setDash([])
        if arrow:
            (x0,y0),(x1,y1)=points[-2:];a=math.atan2(y1-y0,x1-x0)
            q=C.beginPath();q.moveTo(x1,y1)
            for sgn in [-1,1]:
                q.lineTo(x1-4*math.cos(a)+sgn*1.8*math.sin(a),y1-4*math.sin(a)-sgn*1.8*math.cos(a))
            q.close();C.drawPath(q,stroke=1,fill=1)
    def start(name,h):
        nonlocal C
        C=canvas.Canvas(str(out/(name+'.pdf')),pagesize=(500,h))
        C.setTitle(name+' — ASSURE-BVLOS conceptual artwork')
        C.setAuthor('Nick Barua');C.setCreator('ReportLab vector diagram script')
    def save(name):
        C.showPage();C.save()
        if args.eps:
            subprocess.run(['pdftops','-eps',str(out/(name+'.pdf')),str(out/(name+'.eps'))],check=True)

    name='Figure_1_conceptual';start(name,310)
    labels=['Space / aerial links\nLEO / GEO / HAPS','Air vehicle\nC2 + sensing','Ground / edge\n5G, GCS, UTM','External data\nEO, weather, maps','Operator and\nauthority']
    for i,label in enumerate(labels):rect(5+100*i,268,90,36,label,9)
    # All monitored sources feed a common data layer before normalisation.
    for x in (50,150,250,350):line([(x,268),(x,254)])
    line([(50,254),(350,254)])
    rect(15,202,125,40,'Trusted data layer\nprovenance · age · integrity',9)
    rect(170,202,142,40,'Runtime monitors\nnormalised scores and fault flags',9)
    rect(360,202,130,40,'Safety constraints\nand hard limits',9)
    line([(77.5,254),(77.5,242)],True)
    line([(450,268),(450,254),(425,254),(425,242)],True)
    line([(140,222),(170,222)],True)
    # Crucially, hard-limit inputs bypass the scalar fusion block.
    line([(312,222),(360,222)],True)
    rect(170,127,142,45,'Risk fusion\nR + uncertainty penalties\nclipped to [0,1]',9)
    rect(360,127,130,45,'Adaptive authority manager\nS0 nominal to\nS4 minimum risk',9)
    line([(241,202),(241,172)],True)
    line([(425,202),(425,172)],True)
    line([(312,149.5),(360,149.5)],True)
    rect(345,61,145,40,'Predefined response set\nconstrain · hold · divert · land',9)
    rect(190,61,115,40,'Human–machine\ninterface',9)
    line([(425,127),(425,101)],True)
    line([(345,81),(305,81)],True)
    rect(120,7,350,34,'Digital safety-case evidence\nclaim · trigger · action · outcome · configuration',9)
    line([(417.5,61),(417.5,41)],True)
    line([(247.5,61),(247.5,41)],True)
    save(name)

    name='Figure_2_conceptual';start(name,182)
    text(250,169,'Increasing conservatism of the requested response',9)
    line([(18,156),(482,156)],True)
    bounds=[0,.25,.42,.60,.76,1];left=16;width=468
    labels=['S0\nNominal','S1\nConstrained','S2\nProtected\nautonomy','S3\nContingency','S4\nMinimum risk /\nterminate']
    for i,label in enumerate(labels):
        x=left+width*bounds[i];w=width*(bounds[i+1]-bounds[i])
        C.setLineWidth(.75);C.rect(x,84,w,50,stroke=1,fill=0)
        text(x+w/2,109,label,9,10)
    for val in bounds:
        x=left+width*val;line([(x,84),(x,78)])
        text(x,69,f'{val:.2f}',9)
    text(250,53,'Uncertainty-adjusted mission-risk index, R*',9)
    # Recovery is from S1--S3 only: S4 is latched in the implementation.
    line([(left+width*.755,36),(left+width*.01,36)],True)
    text(193,22,'Recovery: one band after sustained qualifying evidence',9)
    text(435,26,'S4 remains latched\nuntil explicit reset',8.6,10)
    save(name)

    name='Figure_3_conceptual';start(name,247)
    rect(102,198,296,39,'Proposed top-level claim\nOperation remains within the approved risk envelope',8.8)
    xs=[5,105,205,305,405];centres=[x+45 for x in xs]
    line([(250,198),(250,184)])
    line([(centres[0],184),(centres[-1],184)])
    labels=['G1\nC2 integrity','G2\nPerception integrity','G3\nVehicle and\nenvironment','G4\nFallback feasibility','G5\nHuman awareness']
    evid=['Link health,\nmonitor status','Confidence,\ndisagreement','Health, weather,\nenergy','Reachability,\nminimum-risk path','Mode annunciation,\nacknowledgement']
    for x,c,label,ev in zip(xs,centres,labels,evid):
        rect(x,127,90,42,label,9);line([(c,184),(c,169)])
        rect(x,66,90,42,ev,9);line([(c,127),(c,108)])
        line([(c,66),(c,51)])
    line([(centres[0],51),(centres[-1],51)])
    rect(93,3,314,34,'Time-indexed evidence record\nsource · configuration · trigger · transition · execution · outcome',9)
    line([(250,51),(250,37)])
    save(name)
    print('Three conceptual diagrams exported. No numerical model or results changed.')
if __name__=='__main__':main()
