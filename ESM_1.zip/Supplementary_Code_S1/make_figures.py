#!/usr/bin/env python3
"""Regenerate numerical figures from saved results; no old numerical image is reused."""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
# Embed TrueType fonts in publication vectors.
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42

def main():
 p=argparse.ArgumentParser();p.add_argument('--results',default='results');p.add_argument('--output',default='figures');a=p.parse_args()
 r=Path(a.results);out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
 s=json.loads((r/'summary.json').read_text());d=np.load(r/'primary_states.npz')
 def finish(fig,name):
  fig.tight_layout()
  fig.savefig(out/(name+'.png'),dpi=600)
  fig.savefig(out/(name+'.pdf'))
  fig.savefig(out/(name+'.eps'))
  plt.close(fig)
 fig,ax=plt.subplots(figsize=(7.1,3.7));ax.boxplot(d['risk'],tick_labels=['C2','Sensing','Data','Environment','Vehicle'],whis=(5,95),showfliers=False)
 ax.set_ylabel('Normalised domain score');ax.set_ylim(0,1);finish(fig,'Figure_4_domain_distributions')
 fig,ax=plt.subplots(figsize=(7.1,3.7));vals=[100*s['baseline_probability'],100*s['assure_probability']]
 bars=ax.bar(['Static hard-limit baseline','ASSURE-BVLOS'],vals,width=.52)
 for b,n in zip(bars,[s['baseline_count'],s['assure_count']]):
  ax.annotate(f'{n/1000:.3f}%\n({n:,}/100,000)',(b.get_x()+b.get_width()/2,b.get_height()),xytext=(0,6),textcoords='offset points',ha='center',fontsize=10)
 ax.set_ylabel('Estimated simulated hazardous-outcome\nprobability (%)');ax.set_ylim(0,13.5);finish(fig,'Figure_5_primary_comparison')
 f=pd.read_csv(r/'scenario_results.csv');fig,ax=plt.subplots(figsize=(7.1,3.8));x=np.arange(3);width=.35
 for off,key,label in [(-width/2,'baseline_probability','Static hard-limit baseline'),(width/2,'assure_probability','ASSURE-BVLOS')]:
  bars=ax.bar(x+off,100*f[key],width,label=label,hatch='//' if key=='assure_probability' else None)
  for b,v in zip(bars,100*f[key]):ax.annotate(f'{v:.2f}',(b.get_x()+b.get_width()/2,v),xytext=(0,3),textcoords='offset points',ha='center',fontsize=9)
 ax.set_xticks(x,['Disaster\nresponse','Linear-infrastructure\ninspection','Maritime\nsurveillance']);ax.set_ylim(0,17.3);ax.legend(frameon=False,ncols=2,loc='upper center',fontsize=9)
 ax.set_ylabel('Estimated simulated hazardous-outcome\nprobability (%)');finish(fig,'Figure_6_scenario_comparison')
 f=pd.read_csv(r/'threshold_sweep.csv');fig,ax=plt.subplots(figsize=(7.1,3.8));ax.plot(100*f['intervention_fraction'],100*f['critical_recall'],marker='o',markersize=4)
 for mult in [.7,.9,1.,1.1,1.3]:
  v=f[np.isclose(f['multiplier'],mult)].iloc[0]
  offsets={.7:(10,-3),.9:(15,-14),1.:(24,-9),1.1:(32,-7),1.3:(12,-25)}
  ax.annotate(f'×{mult:.2f}',(100*v.intervention_fraction,100*v.critical_recall),xytext=offsets[mult],textcoords='offset points',fontsize=9,arrowprops=dict(arrowstyle='-',lw=.6))
 ax.set_xlabel('Intervention burden: sampled states assigned S2–S4 (%)');ax.set_ylabel('Recall of configured critical states (%)');ax.set_xlim(0,60);ax.set_ylim(0,104);finish(fig,'Figure_7_recall_burden')
 f=pd.read_csv(r/'vehicle_weight_sweep.csv');fig,ax=plt.subplots(figsize=(7.1,3.7));ax.plot(f.vehicle_weight,100*f.critical_recall,'o-',label='Critical-state recall');ax.plot(f.vehicle_weight,100*f.intervention_fraction,'s--',label='Intervention burden');ax.legend(frameon=False);ax.set_xlabel('Vehicle-health weight (other four weights share the remainder)');ax.set_ylabel('Proportion (%)');ax.set_ylim(0,75);finish(fig,'Figure_S1_vehicle_weight')
 f=pd.read_csv(r/'intervention_risk_sensitivity.csv');fig,ax=plt.subplots(figsize=(7.1,3.7));ax.plot(100*f.additional_intervention_risk,100*f.expected_difference,'o-');ax.axhline(0,linestyle='--',linewidth=1);ax.set_xlabel('Added conditional adverse probability per additional\nauthority assignment (percentage points)');ax.set_ylabel('Mean conditional probability difference\n(baseline − ASSURE; percentage points)');finish(fig,'Figure_S2_adverse_intervention')
 f=pd.read_csv(r/'temporal_example.csv');fig,ax=plt.subplots(figsize=(7.1,3.7));ax.step(f.tick,f.memoryless_state,where='post',label='Memoryless');ax.step(f.tick,f.hysteretic_state,where='post',label='Hysteretic',linestyle='--');ax.set_xlabel('Logic-test time (s; prescribed inputs, not a flight trajectory)');ax.set_ylabel('Requested authority state');ax.set_yticks(range(5),['S0','S1','S2','S3','S4']);ax.set_ylim(-.2,4.4);ax.legend(frameon=False,ncols=2);finish(fig,'Figure_S3_temporal_logic')
 print('Seven numerical figures regenerated from the executed reference study.')
if __name__=='__main__':main()
